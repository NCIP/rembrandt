package gov.nih.nci.nautilus.de;

/**
 * Created by IntelliJ IDEA.
 * User: BhattarR
 * Date: Aug 6, 2004
 * Time: 10:48:18 AM
 * To change this template use Options | File Templates.
 */
public class Test {
    public static void main(String[] args) {
    System.out.println("First Time");
     DomainElementClass[] objs1 = new DomainElementClass[] { DomainElementClass.LOCUS_LINK, DomainElementClass.GENBANK_ACCESSION_NUMBER };
     System.out.println("LocusLink Nmae: " + objs1[0].getName() + "hCode: " + objs1[0].hashCode());
     System.out.println("GenBankAccession Nmae: " + objs1[1].getName() + "hCode: " + objs1[1].hashCode());

    System.out.println("Second Time");
     DomainElementClass[] objs2 = new DomainElementClass[] { DomainElementClass.LOCUS_LINK, DomainElementClass.GENBANK_ACCESSION_NUMBER };
     System.out.println("LocusLink Nmae: " + objs2[0].getName() + "hCode: " + objs2[0].hashCode());
     System.out.println("GenBankAccession Nmae: " + objs2[1].getName() + "hCode: " + objs2[1].hashCode());

       // ClassLoader.class.getDeclaredClasses()
        //GeneIdentifierDE ll = new GeneIdentifierDE.LocusLink();
        //System.out.println("Chromoseome NUmber : " + ChromosomeNumberDE.LABEL);
        //Class c = null;

        //try {
         //   c = Class.forName("gov.nih.nci.nautilus.de.ChromosomeNumberDE");


        //} catch (ClassNotFoundException e) {
          //  e.printStackTrace();  //To change body of catch statement use Options | File Templates.
        //}
        //System.out.println("clName: " + c.getSuperclass());

        /*GeneIdentifierDE.LocusLink lobj1 = new GeneIdentifierDE.LocusLink();
        lobj1.setValueObject("1234");
        System.out.println("1234: " + lobj1.getValueObject());

        GeneIdentifierDE.LocusLink lobj2 = new GeneIdentifierDE.LocusLink();
        lobj2.setValueObject("abcd");
        System.out.println("abcd: " + lobj2.getValueObject());

        System.out.println("1234: " + lobj1.getValueObject());

        ExprFoldChangeDE.UpRegulation eobj = new ExprFoldChangeDE.UpRegulation();
        eobj.setValueObject(new Float("3.456"));
        System.out.println("3.456: " + eobj.getValueObject());
*/
    }
}
