package gov.nih.nci.nautilus.view;

import gov.nih.nci.nautilus.de.*;

/**
 * Created by IntelliJ IDEA.
 * User: BhattarR
 * Date: Aug 13, 2004
 * Time: 4:39:51 PM
 * To change this template use Options | File Templates.
 */

public class GeneView {
    GeneIdentifierDE.LocusLink locusLink;
    GeneIdentifierDE.GeneSymbol geneSymbol;
    GeneIdentifierDE.GenBankAccessionNumber genBankAccnNo;
    CytobandDE cytoband;
    //TODO: what kind of foldchange
    ExprFoldChangeDE foldChnage;
    ProbeSetDE probeSet;

}
