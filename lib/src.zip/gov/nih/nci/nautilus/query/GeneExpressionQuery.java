package gov.nih.nci.nautilus.query;

import gov.nih.nci.nautilus.criteria.*;
import gov.nih.nci.nautilus.queryprocessing.QueryHandler;
import gov.nih.nci.nautilus.queryprocessing.GeneExprQueryHandler;

/**
 * Created by IntelliJ IDEA.
 * User: BhattarR
 * Date: Aug 12, 2004
 * Time: 6:46:14 PM
 * To change this template use Options | File Templates.
 */
public class GeneExpressionQuery extends Query {

    private GeneIDCriteria geneIDCrit;
    private RegionCriteria regionCrit;
    private FoldChangeCriteria foldChgCrit;
    private CloneOrProbeIDCriteria cloneProbeCrit;
    private ArrayPlatformCriteria platCriteria;
    private QueryHandler HANDLER;

    public ArrayPlatformCriteria getPlatCriteria() {
        return platCriteria;
    }

    public void setPlatCriteria(ArrayPlatformCriteria platCriteria) {
        this.platCriteria = platCriteria;
    }


    public CloneOrProbeIDCriteria getCloneProbeCrit() {
        return cloneProbeCrit;
    }

    public void setCloneProbeCrit(CloneOrProbeIDCriteria cloneProbeCrit) {
        this.cloneProbeCrit = cloneProbeCrit;
    }


    public QueryHandler getQueryHandler() throws Exception  {
        return (HANDLER == null) ? new GeneExprQueryHandler() : HANDLER;
    }

    public GeneExpressionQuery() {
        super();
    }

    public GeneIDCriteria getGeneIDCrit() {
        return geneIDCrit;
    }

    public void setGeneIDCrit(GeneIDCriteria geneIDCrit) {
        this.geneIDCrit = geneIDCrit;
    }

    public RegionCriteria getRegionCrit() {
        return regionCrit;
    }

    public void setRegionCrit(RegionCriteria regionCrit) {
        this.regionCrit = regionCrit;
    }

    public FoldChangeCriteria getFoldChgCrit() {
        return foldChgCrit;
    }

    public void setFoldChgCrit(FoldChangeCriteria foldChgCrit) {
        this.foldChgCrit = foldChgCrit;
    }

    class Handler {

    }
}
