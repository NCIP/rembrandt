package gov.nih.nci.nautilus.queryprocessing;

import gov.nih.nci.nautilus.query.GeneExpressionQuery;
import gov.nih.nci.nautilus.query.Query;
import gov.nih.nci.nautilus.criteria.CloneOrProbeIDCriteria;
import gov.nih.nci.nautilus.criteria.ArrayPlatformCriteria;
import gov.nih.nci.nautilus.criteria.Constants;
import gov.nih.nci.nautilus.de.ArrayPlatformDE;
import gov.nih.nci.nautilus.de.CloneIdentifierDE;
import gov.nih.nci.nautilus.de.GeneIdentifierDE;
import gov.nih.nci.nautilus.data.ProbesetDim;
import gov.nih.nci.nautilus.data.CloneDim;
import gov.nih.nci.nautilus.data.ReporterAll;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Iterator;
import java.math.BigDecimal;

import org.apache.ojb.broker.query.Criteria;
import org.apache.ojb.broker.query.QueryFactory;
import org.apache.ojb.broker.query.ReportQuery;
import org.apache.ojb.broker.query.ReportQueryByCriteria;
import org.apache.ojb.broker.PersistenceBroker;

/**
 * Created by IntelliJ IDEA.
 * User: BhattarR
 * Date: Aug 28, 2004
 * Time: 4:32:54 PM
 * To change this template use Options | File Templates.
 */
public class CloneProbePlatfromHandler {

    static  GeneExprQueryHandler.ReporterIDCriteria buildCloneProbePlatformCriteria(CloneOrProbeIDCriteria cloneOrProbeCrit,  ArrayPlatformCriteria platCrit, PersistenceBroker _BROKER) throws Exception{
        /* idsCrits will be populated with sets of CloneIDs and ProbesetIDs as
            two different collections.  This is based on Array Platform criteria and
            specified Clone/Probe IDs.
        */
        GeneExprQueryHandler.ReporterIDCriteria idsCriteria = new GeneExprQueryHandler.ReporterIDCriteria();

        if (cloneOrProbeCrit != null ) {
            String probeType = getType(cloneOrProbeCrit);
            Collection inputCloneOrProbeDEs = cloneOrProbeCrit.getIdentifiers();

            // convert ProbeNames/CloneNames into ProbesetIDs/CloneIDs
            ReportQueryByCriteria inputIDQuery = getCloneOrProbeIDsFromNameDEs(inputCloneOrProbeDEs, probeType, _BROKER);

            if (platCrit != null) {
                ArrayPlatformDE platObj = platCrit.getPlatform();
                if (platObj.getValueObject().equalsIgnoreCase(Constants.ALL_PLATFROM)) {
                    // use both cloneIDs and ProbesetIDs
                     if (probeType.equalsIgnoreCase(CloneIdentifierDE.PROBE_SET)) {
                        // this means inputIDs represent probesetIDs
                        ReportQueryByCriteria geneSymbolQuery = getGeneSymbolsForProbeIDs(inputIDQuery, _BROKER);
                        ReportQueryByCriteria cloneIDsQuery = getCloneIDsFor(geneSymbolQuery, _BROKER);
                        idsCriteria.setProbeIDsSubQuery(inputIDQuery);
                        idsCriteria.setCloneIDsSubQuery(cloneIDsQuery);
                     }
                     else if (probeType.equalsIgnoreCase(CloneIdentifierDE.IMAGE_CLONE) ||
                             probeType.equalsIgnoreCase(CloneIdentifierDE.BAC_CLONE)) {
                        // this means inputIDs represent cloneIDs
                        ReportQueryByCriteria geneSymbolQuery = getGeneSymbolsForCloneIDs(inputIDQuery, _BROKER);
                        ReportQueryByCriteria probeIDsQuery = getProbeIDsFor(geneSymbolQuery, _BROKER);
                        idsCriteria.setProbeIDsSubQuery(probeIDsQuery);
                        idsCriteria.setCloneIDsSubQuery(inputIDQuery);
                     }
                }
                else if (platObj.getValueObject().equalsIgnoreCase(Constants.AFFY_OLIGO_PLATFORM)) {
                    if (probeType.equalsIgnoreCase(CloneIdentifierDE.IMAGE_CLONE)||
                            probeType.equalsIgnoreCase(CloneIdentifierDE.BAC_CLONE)) {
                        /* this means inputIDs represent cloneIDs.  So convert these cloneIDs to
                        ProbesetIDs by going through GeneSymbol */
                        ReportQueryByCriteria geneSymbolQuery = getGeneSymbolsForCloneIDs(inputIDQuery, _BROKER);
                        ReportQueryByCriteria  probeIDsQuery = getProbeIDsFor(geneSymbolQuery, _BROKER);
                        idsCriteria.setProbeIDsSubQuery(probeIDsQuery);
                    }
                    else if  (probeType.equalsIgnoreCase(CloneIdentifierDE.PROBE_SET)) {
                         /* means inputIDs represent probeIDs  Since platform requested was OLIGO(Affy),
                            this means only probeIDs should be in the final result set */
                        idsCriteria.setProbeIDsSubQuery(inputIDQuery);
                    }
                }
                else if (platObj.getValueObject().equalsIgnoreCase(Constants.CDNA_ARRAY_PLATFORM)) {
                     if (probeType.equalsIgnoreCase(CloneIdentifierDE.PROBE_SET)) {
                        /* this means inputIDs represent probesetIDs.  So convert probesetID to
                         cloneIDs by going through GeneSymbol */
                        ReportQueryByCriteria geneSymbolQuery = getGeneSymbolsForProbeIDs(inputIDQuery, _BROKER);
                        ReportQueryByCriteria cloneIDsQuery = getCloneIDsFor(geneSymbolQuery, _BROKER);
                        idsCriteria.setCloneIDsSubQuery(cloneIDsQuery);
                    }
                     else if (probeType.equalsIgnoreCase(CloneIdentifierDE.IMAGE_CLONE)||
                            probeType.equalsIgnoreCase(CloneIdentifierDE.BAC_CLONE)) {
                         /* means inputIDs represent cloneIDs  Since platform requested was cDNA,
                            this means only cloneIDs should be in the final result set */
                          idsCriteria.setCloneIDsSubQuery(inputIDQuery);
                     }
                }
            }
        }
        return idsCriteria;
    }

    /*  This method converts ProbesetNames/CloneNames into thier respective IDs
    */
    private static ReportQueryByCriteria getCloneOrProbeIDsFromNameDEs(Collection probeOrCloneDEs, String probeType, PersistenceBroker _BROKER) throws Exception {
        Collection deNames = new ArrayList();
        org.apache.ojb.broker.query.ReportQueryByCriteria IDsQuery = null;
        for (Iterator iterator = probeOrCloneDEs.iterator(); iterator.hasNext();)
              deNames.add(((CloneIdentifierDE) iterator.next()).getValueObject());

        String nameCol = null;
        String idCol = null;
        if (probeType.equals(CloneIdentifierDE.PROBE_SET)) {
           nameCol = GeneExprQueryHandler.getColumnName(_BROKER, CloneIdentifierDE.ProbesetID.class.getName());
           idCol = GeneExprQueryHandler.getColumnName(_BROKER, ProbesetDim.class.getName(), ProbesetDim.PROBESET_ID);
           Criteria c = new Criteria();
           c.addColumnIn(nameCol, deNames);
           IDsQuery = QueryFactory.newReportQuery(ProbesetDim.class, new String[] {idCol}, c, true);
        }
        else if (probeType.equals(CloneIdentifierDE.IMAGE_CLONE) || probeType.equals(CloneIdentifierDE.BAC_CLONE) ) {
            nameCol = GeneExprQueryHandler.getColumnName(_BROKER, CloneIdentifierDE.IMAGEClone.class.getName());
            idCol = GeneExprQueryHandler.getColumnName(_BROKER, CloneDim.class.getName(), CloneDim.CLONE_ID);
            Criteria c = new Criteria();
            c.addColumnIn(nameCol, deNames);
            IDsQuery  =  QueryFactory.newReportQuery(CloneDim.class, new String[] {idCol}, c, true);
        }
        return IDsQuery ;
    }
    private static ReportQueryByCriteria  getCloneIDsFor(ReportQueryByCriteria  geneSymbolQuery, PersistenceBroker _BROKER) throws Exception {
        String cloneIDCol = GeneExprQueryHandler.getColumnName(_BROKER, CloneDim.class.getName(), CloneDim.CLONE_ID);
        return getCloneOrProbeIDsFor(geneSymbolQuery, cloneIDCol, CloneDim.class, _BROKER);
    }
    private static ReportQueryByCriteria getProbeIDsFor(ReportQueryByCriteria geneSymbolQuery, PersistenceBroker _BROKER) throws Exception {
        String probeIDCol = GeneExprQueryHandler.getColumnName(_BROKER, ProbesetDim.class.getName(), ProbesetDim.PROBESET_ID);
        return getCloneOrProbeIDsFor(geneSymbolQuery, probeIDCol, ProbesetDim.class, _BROKER);
    }

    private static ReportQueryByCriteria  getCloneOrProbeIDsFor(ReportQueryByCriteria geneSymbolQuery, String cloneOrProbeIDCol, Class classToSearch, PersistenceBroker _BROKER) throws Exception {

        Criteria clonOrProbeIDCrit = new Criteria();
        clonOrProbeIDCrit.addIn(ReporterAll.GENE_SYMBOL,  geneSymbolQuery);
        org.apache.ojb.broker.query.ReportQueryByCriteria cloneOrProbeIDSQuery =
                QueryFactory.newReportQuery(classToSearch, new String[] {cloneOrProbeIDCol}, clonOrProbeIDCrit , true);
        return cloneOrProbeIDSQuery;
    }

    private static ReportQueryByCriteria getGeneSymbolsForProbeIDs(ReportQueryByCriteria probeIDSubQuery, PersistenceBroker _BROKER) throws Exception {
        return getGeneSymbolsForCloneOrProbesetIDs(probeIDSubQuery, ProbesetDim.PROBESET_ID, ProbesetDim.class, _BROKER);
    }

    private static ReportQueryByCriteria getGeneSymbolsForCloneIDs(ReportQueryByCriteria cloneIDSubQuery, PersistenceBroker _BROKER) throws Exception {
        return getGeneSymbolsForCloneOrProbesetIDs(cloneIDSubQuery, CloneDim.CLONE_ID, CloneDim.class, _BROKER);
    }

    private static ReportQueryByCriteria getGeneSymbolsForCloneOrProbesetIDs(ReportQueryByCriteria probeOrCloneIDSubQuery, String probeOrCloneIDAttrName, Class classToSearch,PersistenceBroker _BROKER) throws Exception {
        String geneSymbolCol = GeneExprQueryHandler.getColumnName(_BROKER, GeneIdentifierDE.GeneSymbol.class.getName());
        Criteria cloneOrProbeCriteria = new Criteria();
        cloneOrProbeCriteria.addIn(probeOrCloneIDAttrName, probeOrCloneIDSubQuery);
        org.apache.ojb.broker.query.ReportQueryByCriteria geneSymbolQuery =
                QueryFactory.newReportQuery(classToSearch, new String[] {geneSymbolCol}, cloneOrProbeCriteria , true);
        return geneSymbolQuery;
    }

    private static String getType(CloneOrProbeIDCriteria cloneProbeCrit ) {
        if (cloneProbeCrit != null ) {
            Collection cloneIDorProbeIDs = cloneProbeCrit.getIdentifiers();
             if (cloneIDorProbeIDs.size() > 0) {
                 CloneIdentifierDE obj =  (CloneIdentifierDE ) cloneIDorProbeIDs.iterator().next();
                 return obj.getCloneIDType();
             }
        }
        return "";
    }

}
