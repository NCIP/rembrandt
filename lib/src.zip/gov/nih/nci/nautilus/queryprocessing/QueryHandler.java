package gov.nih.nci.nautilus.queryprocessing;

import gov.nih.nci.nautilus.query.Query;
import gov.nih.nci.nautilus.criteria.Criteria;
import gov.nih.nci.nautilus.criteria.RegionCriteria;
import gov.nih.nci.nautilus.criteria.FoldChangeCriteria;
import gov.nih.nci.nautilus.data.ProbesetDim;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.io.InputStream;

import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.jdom.input.SAXBuilder;
import org.apache.ojb.broker.metadata.FieldDescriptor;
import org.apache.ojb.broker.metadata.DescriptorRepository;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.PersistenceBroker;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;



/**
 * Created by IntelliJ IDEA.
 * User: BhattarR
 * Date: Aug 20, 2004
 * Time: 3:06:52 PM
 * To change this template use Options | File Templates.
 */
abstract public class QueryHandler {
    private static HashMap deBeanMappings = new HashMap();
    private final static String FILE_NAME ="/deToBeanAttrMappings.xml";
    private static HashMap beanCriteriaMappings = new HashMap();
    abstract void handle(Query query) throws Exception;
    static {
        beanCriteriaMappings.put(RegionCriteria.class.getName(), ProbesetDim.class.getName());
        beanCriteriaMappings.put(FoldChangeCriteria.class.getName(), ProbesetDim.class.getName());
        //TODO: complete this
       try {
            SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
            InputStream inStream = QueryHandler.class.getResourceAsStream(FILE_NAME);
            if( inStream == null ){
	            inStream = Thread.currentThread().getContextClassLoader().getResourceAsStream( FILE_NAME );
            }
            parser.parse(inStream, new DEBeanMappingsHandler());
       } catch(Throwable t) {
           //TODO: rethrow this exception with some message
           t.printStackTrace();
       }
    }
    final  static String getBeanNameFor(Criteria crit) throws Exception {
        Object value = beanCriteriaMappings.get(crit.getClass().getName());
        if (value == null)
            throw new Exception("Associated Bean class is not found for the Criteria: " + crit.getClass().getName());
        return  (String) value;
    }

    final static DEBeanAttrMapping getBeanAttrMappingFor(String deClassName) throws Exception {
        Object value = deBeanMappings.get(deClassName);
        if (value == null)
           throw new Exception("DEBeanAttrMapping  could not be found for: " + deClassName);
        return (DEBeanAttrMapping) value;
    }

    protected static String getColumnName(PersistenceBroker pb, String deClassName) throws Exception {
        DescriptorRepository dr = pb.getDescriptorRepository();
        DEBeanAttrMapping mappingObj = getBeanAttrMappingFor(deClassName);
        String beanName = mappingObj.mappedBean;
        String beanAttrName = mappingObj.mappedBeanAttribute;
        ClassDescriptor cd = dr.getDescriptorFor( beanName );
        FieldDescriptor fd = cd.getFieldDescriptorByName(beanAttrName);
        return fd.getColumnName();
    }
     // used in report queries for columnNames attrributes
     protected static String getColumnName(PersistenceBroker pb, String beanClassName, String attrName) throws Exception {
        DescriptorRepository dr = pb.getDescriptorRepository();
        ClassDescriptor cd = dr.getDescriptorFor( beanClassName );
        FieldDescriptor fd = cd.getFieldDescriptorByName(attrName);
        return fd.getColumnName();
    }

    private final static class DEBeanMappingsHandler extends DefaultHandler {
        public void startElement(String uri, String localName,  String qName, Attributes attributes)
        throws SAXException {
            if (qName.equalsIgnoreCase("DomainElement")) {
              DEBeanAttrMapping deMapObj = new DEBeanAttrMapping();
              for (int i = 0; i < attributes.getLength(); ++i) {
                  if (attributes.getQName(i).equals("name"))
                      deMapObj.name = attributes.getValue(i);
                  else if (attributes.getQName(i).equals("mappedBean"))
                      deMapObj.mappedBean = attributes.getValue(i);
                  else if (attributes.getQName(i).equals("mappedBeanAttribute"))
                      deMapObj.mappedBeanAttribute = attributes.getValue(i);
              }
              deBeanMappings.put(deMapObj.name, deMapObj);
            }
        }
    }
    protected static class DEBeanAttrMapping  {
        String mappedBean;
        String mappedBeanAttribute;
        String name;
        public DEBeanAttrMapping() {}
        public DEBeanAttrMapping(String name, String mappedBeanName, String beanAttributeName) {
            this.name = name;
            this.mappedBean = mappedBeanName;
            this.mappedBeanAttribute = beanAttributeName;
        }
    }
}
