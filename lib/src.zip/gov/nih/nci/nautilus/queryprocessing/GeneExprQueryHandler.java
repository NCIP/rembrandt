package gov.nih.nci.nautilus.queryprocessing;

import gov.nih.nci.nautilus.query.Query;
import gov.nih.nci.nautilus.query.GeneExpressionQuery;
import gov.nih.nci.nautilus.criteria.*;
import gov.nih.nci.nautilus.de.*;
import gov.nih.nci.nautilus.data.ProbesetDim;
import gov.nih.nci.nautilus.data.DifferentialExpressionSfact;
import gov.nih.nci.nautilus.data.ReporterAll;
import gov.nih.nci.nautilus.data.CloneDim;

import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

import org.apache.ojb.broker.query.*;
import org.apache.ojb.broker.query.Criteria;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerFactory;

/**
 * Created by IntelliJ IDEA.
 * User: BhattarR
 * Date: Aug 20, 2004
 * Time: 3:14:46 PM
 * To change this template use Options | File Templates.
 */
public class GeneExprQueryHandler extends QueryHandler {
    FoldChangeCriteria foldCrit;
    GeneIDCriteria  geneIDCrit;
    PersistenceBroker _BROKER = PersistenceBrokerFactory.defaultPersistenceBroker();

    public void handle(gov.nih.nci.nautilus.query.Query query) throws Exception {
        GeneExpressionQuery geQuery = (GeneExpressionQuery) query;

        Criteria crit = new Criteria();




        //GeneExprQueryHandler.ReporterIDCriteria cpCrit = new GeneExprQueryHandler.ReporterIDCriteria();


        GeneExprQueryHandler.ReporterIDCriteria geneBasedIDCrit = buildGeneIDCriteria(geQuery.getGeneIDCrit(), _BROKER);
        Criteria idCritBasedOnGenes = geneBasedIDCrit.handle();

        addRegionCriteria(geQuery.getRegionCrit(), _BROKER, crit);

        CloneOrProbeIDCriteria cloneOrProbeCrit = geQuery.getCloneProbeCrit();
        ArrayPlatformCriteria platCriteria = geQuery.getPlatCriteria();
        GeneExprQueryHandler.ReporterIDCriteria platformCloneProbeBasedCrit =
                 CloneProbePlatfromHandler.buildCloneProbePlatformCriteria(cloneOrProbeCrit, platCriteria, _BROKER);

        Criteria platBasedCrit = platformCloneProbeBasedCrit.handle();
        //ReportQueryByCriteria cloneIDsQuery = platformCloneProbeBasedIDCrit.getCloneIDsSubQuery();
        //ReportQueryByCriteria probeIDsQuery = platformCloneProbeBasedIDCrit.getProbeIDsSubQuery();



        Criteria diffExprCrit= new Criteria();
        addFoldChangeCriteria(geQuery.getFoldChgCrit(), _BROKER, diffExprCrit);

        /*Criteria cloneIDs = new Criteria();
        cloneIDs.addIn(DifferentialExpressionSfact.CLONE_ID, cloneIDsQuery);
        Criteria probeIDs = new Criteria();
        probeIDs.addIn(DifferentialExpressionSfact.PROBESET_ID, probeIDsQuery);
        cloneIDs.addOrCriteria(probeIDs);*/

        platBasedCrit.addOrCriteria(idCritBasedOnGenes);
        diffExprCrit.addAndCriteria(platBasedCrit);

        org.apache.ojb.broker.query.Query geneExprQuery = QueryFactory.newQuery(
                DifferentialExpressionSfact.class, diffExprCrit);
        Collection exprObjects =   _BROKER.getCollectionByQuery(geneExprQuery);
        for (Iterator iterator = exprObjects.iterator(); iterator.hasNext();) {
            DifferentialExpressionSfact exprObj = (DifferentialExpressionSfact) iterator.next();
            if (exprObj.getProbesetId() != null)
                System.out.println("ProbesetID: " + exprObj.getProbesetId() + " :Exp Value: " + exprObj.getExpressionRatio());
            if ( exprObj.getCloneId() != null)
                System.out.println("CloneID: " + exprObj.getCloneId()+ " :Exp Value: " + exprObj.getExpressionRatio());
        }

    }


    private static GeneExprQueryHandler.ReporterIDCriteria  buildGeneIDCriteria( GeneIDCriteria  geneIDCrit, PersistenceBroker pb ) throws Exception {
        GeneExprQueryHandler.ReporterIDCriteria cloneIDProbeIDCrit = new GeneExprQueryHandler.ReporterIDCriteria();
        if (geneIDCrit != null && geneIDCrit.getGeneIdentifiers().size() > 0) {
            Collection geneIdDEs = geneIDCrit.getGeneIdentifiers();
            String deClassName = getGeneIDClassName(geneIDCrit);
            ArrayList geneIDs = new ArrayList();
            for (Iterator iterator = geneIdDEs.iterator(); iterator.hasNext();)
                geneIDs.add(((GeneIdentifierDE) iterator.next()).getValueObject());

            Criteria geneIDOJBCrit = new Criteria();
            String colName = getColumnName(pb, deClassName);
            geneIDOJBCrit.addIn(colName, geneIDs);
            String geneSymbolColumn = getColumnName(pb, ReporterAll.class.getName(), ReporterAll.GENE_SYMBOL);
            ReportQueryByCriteria geneSymbolQuery = QueryFactory.newReportQuery(ReporterAll.class,
                        new String[] {geneSymbolColumn}, geneIDOJBCrit, true);
            Criteria geneSymbolCrit = new Criteria();
            geneSymbolCrit.addIn(ReporterAll.GENE_SYMBOL, geneSymbolQuery);

            String probeIDColumn = getColumnName(pb, ProbesetDim.class.getName(), ProbesetDim.PROBESET_ID);
            ReportQueryByCriteria probeIDSubQuery = QueryFactory.newReportQuery(ProbesetDim.class, new String[] {probeIDColumn}, geneSymbolCrit , true );

            String cloneIDColumn = getColumnName(pb, CloneDim.class.getName(), CloneDim.CLONE_ID);
            ReportQueryByCriteria cloneIDSubQuery = QueryFactory.newReportQuery(CloneDim.class, new String[] {cloneIDColumn}, geneSymbolCrit , true );

            cloneIDProbeIDCrit.setProbeIDsSubQuery(probeIDSubQuery);
            cloneIDProbeIDCrit.setCloneIDsSubQuery(cloneIDSubQuery);
        }
        return cloneIDProbeIDCrit ;
     }
     private static String getGeneIDClassName(GeneIDCriteria geneIDCrit ) {
        if (geneIDCrit  != null ) {
            Collection geneIDs = geneIDCrit.getGeneIdentifiers();
             if (geneIDs.size() > 0) {
                 GeneIdentifierDE obj =  (GeneIdentifierDE) geneIDs.iterator().next();
                 return obj.getClass().getName();
             }
        }
        return "";
    }

     private static void addFoldChangeCriteria(FoldChangeCriteria  foldChangeCrit, PersistenceBroker pb, Criteria criteria) throws Exception {
        if (foldChangeCrit != null) {
                String columnName = getColumnName(pb, ExprFoldChangeDE.class.getName());
                Collection objs = foldChangeCrit.getFoldChangeObjects();
                Object[] foldObjs = objs.toArray();

                 // Either only UpRegulation or DownRegulation
                 if (foldObjs.length == 1) {
                     ExprFoldChangeDE foldChgObj = (ExprFoldChangeDE) foldObjs[0];
                     Double foldChange = new Double(foldChgObj.getValueObject().floatValue());
                     addSingleUpORDownCriteria(foldChange, foldChgObj.getRegulationType(), columnName, criteria, pb);
                 }

                 // else it could be EITHER both (UpRegulation or DownRegulation) OR UnChangedRegulation
                 else if (foldObjs.length == 2) {
                    String type = ((ExprFoldChangeDE)foldObjs[0]).getRegulationType();
                    if (type.equals(ExprFoldChangeDE.UNCHANGED_REGULATION_UPPER_LIMIT) || type.equals(ExprFoldChangeDE.UNCHANGED_REGULATION_DOWN_LIMIT) ) {
                        addUnChangedCriteria(foldObjs, columnName, criteria, pb);
                    }
                    else if (type.equals(ExprFoldChangeDE.UP_REGULATION) || type.equals(ExprFoldChangeDE.DOWN_REGULATION) ) {
                        addUpAndDownCriteria(foldObjs, columnName, criteria, pb);
                    }
                 }
                 else {
                    throw new Exception("Invalid number of FoldChange Criteria objects: " + foldObjs.length);
                 }
            }
     }

    private static void addUpAndDownCriteria(Object[] foldObjs, String columnName, Criteria criteria, PersistenceBroker pb) throws Exception {
        String type1 = ((ExprFoldChangeDE)foldObjs[0]).getRegulationType();
        Double foldChange1 = new Double(((ExprFoldChangeDE)foldObjs[0]).getValueObject().floatValue());
        addSingleUpORDownCriteria(foldChange1, type1, columnName, criteria, pb);

        String type2 = ((ExprFoldChangeDE)foldObjs[1]).getRegulationType();
        Double foldChange2 = new Double(((ExprFoldChangeDE)foldObjs[1]).getValueObject().floatValue());
        Criteria fold2Crit = new Criteria();
        addSingleUpORDownCriteria(foldChange2, type2, columnName, fold2Crit, pb);

        criteria.addOrCriteria(fold2Crit);
    }

     private static void addUnChangedCriteria(Object[] foldObjs, String columnName, Criteria criteria, PersistenceBroker pb) throws Exception {

        String type1 = ((ExprFoldChangeDE)foldObjs[0]).getRegulationType();
        Double upperLimit;
        Double lowerLimit;

        if (type1.equals(ExprFoldChangeDE.UNCHANGED_REGULATION_DOWN_LIMIT)) {
            upperLimit = new Double(((ExprFoldChangeDE) foldObjs[0]).getValueObject().floatValue());
            lowerLimit = new Double(((ExprFoldChangeDE)foldObjs[1]).getValueObject().floatValue());
        }
        else {
            upperLimit = new Double(((ExprFoldChangeDE)foldObjs[1]).getValueObject().floatValue());
            lowerLimit = new Double(((ExprFoldChangeDE)foldObjs[0]).getValueObject().floatValue());
        }
        criteria.addBetween(columnName, lowerLimit, upperLimit);
    }

    private static void addSingleUpORDownCriteria(Double foldChange, String type, String colunName, Criteria subCrit, PersistenceBroker pb) throws Exception {

        if (type.equals(ExprFoldChangeDE.UP_REGULATION)) {
            subCrit.addGreaterThan(colunName,foldChange);
        }
        else if (type.equals(ExprFoldChangeDE.DOWN_REGULATION)) {
            double convertedDownFold = 1 / (foldChange.doubleValue());
            subCrit.addLessThan(colunName, new Double(convertedDownFold));
        }
        else {
            throw new Exception("Invalid Regulation: " + type + " Value:" + foldChange);
        }

    }

    private static void addRegionCriteria( RegionCriteria regionCrit, PersistenceBroker pb, Criteria criteria) throws Exception {
        if (regionCrit != null) {
            if (regionCrit.getChromNumber() != null)
                addEqualCriteriaFor(regionCrit.getChromNumber().getValueObject(), ChromosomeNumberDE.class.getName(), pb, criteria);

            if (regionCrit.getStart() != null)
               addEqualCriteriaFor(regionCrit.getStart().getValueObject(), BasePairPositionDE.StartPosition.class.getName(), pb, criteria);

            if (regionCrit.getEnd() != null)
               addEqualCriteriaFor(regionCrit.getEnd().getValueObject(), BasePairPositionDE.EndPosition.class.getName(), pb, criteria);

            if (regionCrit.getCytoband() !=  null)
                addEqualCriteriaFor(regionCrit.getCytoband().getValueObject(), CytobandDE.class.getName(), pb, criteria);
        }
    }

    private static void addEqualCriteriaFor(Object deValueObject, String deClassName, PersistenceBroker pb, Criteria crit ) throws Exception {
        String colName = getColumnName(pb, deClassName);
        crit.addEqualTo(colName, deValueObject);
    }
    public static class ReporterIDCriteria {
        private ReportQueryByCriteria cloneIDsSubQuery;
        private ReportQueryByCriteria probeIDsSubQuery;

        Criteria handle() {
            Criteria combinedIDs = new Criteria();
            combinedIDs.addIn(DifferentialExpressionSfact.CLONE_ID, cloneIDsSubQuery);
            Criteria probeIDs = new Criteria();
            probeIDs.addIn(DifferentialExpressionSfact.PROBESET_ID, probeIDsSubQuery);

            combinedIDs.addOrCriteria(probeIDs);
            return combinedIDs;
        }

        public ReportQueryByCriteria getCloneIDsSubQuery() {
            return cloneIDsSubQuery;
        }

        public void setCloneIDsSubQuery(ReportQueryByCriteria cloneIDsSubQuery) {
            this.cloneIDsSubQuery = cloneIDsSubQuery;
        }

        public ReportQueryByCriteria getProbeIDsSubQuery() {
            return probeIDsSubQuery;
        }

        public void setProbeIDsSubQuery(ReportQueryByCriteria probeIDsSubQuery) {
            this.probeIDsSubQuery = probeIDsSubQuery;
        }
    }
}
