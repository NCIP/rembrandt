package gov.nih.nci.nautilus.queryprocessing;

import gov.nih.nci.nautilus.query.Query;
import gov.nih.nci.nautilus.query.GeneExpressionQuery;
import gov.nih.nci.nautilus.criteria.*;
import gov.nih.nci.nautilus.de.*;
import gov.nih.nci.nautilus.data.ProbesetDim;
import gov.nih.nci.nautilus.data.DifferentialExpressionSfact;
import gov.nih.nci.nautilus.data.ReporterAll;

import java.util.Collection;
import java.util.Iterator;
import java.util.ArrayList;

import org.apache.ojb.broker.query.*;
import org.apache.ojb.broker.query.Criteria;

import org.apache.ojb.broker.PersistenceBroker;
import org.apache.ojb.broker.PersistenceBrokerFactory;
import org.apache.ojb.broker.metadata.DescriptorRepository;
import org.apache.ojb.broker.metadata.ClassDescriptor;
import org.apache.ojb.broker.metadata.FieldDescriptor;

/**
 * Created by IntelliJ IDEA.
 * User: BhattarR
 * Date: Aug 20, 2004
 * Time: 3:14:46 PM
 * To change this template use Options | File Templates.
 */
public class GeneExprQueryHandler extends QueryHandler {
    FoldChangeCriteria foldCrit;
    GeneIDCriteria  geneIDCrit;
    PersistenceBroker _BROKER = PersistenceBrokerFactory.defaultPersistenceBroker();
    public final static String AFFY_OLIGO_PLATFORM = "Affymetrix Oligo Expression Arrays";
    public final static String CDNA_ARRAY_PLATFORM = "cDNA arrays";
    public final static String ALL_PLATFROM = "all";

    public void handle(gov.nih.nci.nautilus.query.Query query) throws Exception {
        GeneExpressionQuery geQuery = (GeneExpressionQuery) query;

        Criteria crit = new Criteria();
        addGeneIDCriteria(geQuery.getGeneIDCrit(), crit, _BROKER);
        addRegionCriteria(geQuery.getRegionCrit(), _BROKER, crit);
        org.apache.ojb.broker.query.Query probeQuery = QueryFactory.newReportQuery(ProbesetDim.class, new String[] {"PROBESET_ID"}, crit, false);

        handleCloneProbePlatformCriteria(geQuery, _BROKER, crit);

        addCloneOrProbeCriteria(geQuery.getCloneProbeCrit(), crit, _BROKER);
        Criteria diffExprCrit= new Criteria();
        addFoldChangeCriteria(geQuery.getFoldChgCrit(), _BROKER, diffExprCrit);

        DifferentialExpressionSfact d = null;
        diffExprCrit.addIn("probesetDim", probeQuery);

        org.apache.ojb.broker.query.Query geneExprQuery = QueryFactory.newQuery(DifferentialExpressionSfact.class, diffExprCrit);
        Collection exprObjects =   _BROKER.getCollectionByQuery(geneExprQuery);
        for (Iterator iterator = exprObjects.iterator(); iterator.hasNext();) {
            DifferentialExpressionSfact exprObj = (DifferentialExpressionSfact) iterator.next();
            System.out.println("exprObj: " + exprObj);
        }

    }

    private void handleCloneProbePlatformCriteria(GeneExpressionQuery geQuery, PersistenceBroker pb, Criteria criteria) throws Exception{
        /* refinedCloneProbeCrit will have modified sets of CloneNames and ProbesetNames as
            two different collections.  This modification is based on Array Platform criteria and
            specified Clone/Probe IDs.
        */
        CloneProbeCriteria refinedCloneProbeCrit = new CloneProbeCriteria();

        CloneOrProbeIDCriteria cloneCrit = geQuery.getCloneProbeCrit();
        String probeType = getType(cloneCrit);
        ArrayPlatformCriteria platCrit = geQuery.getPlatCriteria();

        if (platCrit != null) {
            ArrayPlatformDE platObj = platCrit.getPlatform();
            if (platObj.getValueObject().equalsIgnoreCase(ALL_PLATFROM)) {
                // use both cloneIDs and ProbesetIDs
                 if (probeType.equalsIgnoreCase(CloneIdentifierDE.PROBE_SET)) {
                     Collection probeDECrits = cloneCrit.getIdentifiers();

                     // first retrieve the Gene_Symbol for these ProbeSetNames (reporterNames)
                     Collection geneSymbols = getGeneSymbolsForProbeNames(probeDECrits);

                     // now retrieve all cloneNames for those GeneSymbols
                     Collection cloneNames = getCloneNamesFor(geneSymbols);

                     // convert these cloneNames into CloneIdentifierDE.IMAGEClone objects and add them to collection
                     Collection cloneDECollection = new ArrayList();
                     for (Iterator iterator = cloneNames.iterator(); iterator.hasNext();) {
                         String cloneName  = (String)iterator.next();
                         CloneIdentifierDE.IMAGEClone imgCloneDEObj =  new CloneIdentifierDE.IMAGEClone(cloneName);
                         cloneDECollection.add(imgCloneDEObj);
                     }

                     // now add both of these original probesetDEs and retrieved cloneDEs to refinedCloneProbCrit
                     refinedCloneProbeCrit.setProbeCrtis(probeDECrits);
                     refinedCloneProbeCrit.setCloneCrits(cloneDECollection);
                 }
                 else if (probeType.equalsIgnoreCase(CloneIdentifierDE.IMAGE_CLONE)) {
                     // also add ProbeSetIDs
                 }
            }
            else if (platObj.getValueObject().equalsIgnoreCase(AFFY_OLIGO_PLATFORM)) {
                if (probeType.equalsIgnoreCase(CloneIdentifierDE.IMAGE_CLONE)) {
                    // convert cloneIDs to ProbesetIDs by going through GeneSymbol
                }
            }
            else if (platObj.getValueObject().equalsIgnoreCase(CDNA_ARRAY_PLATFORM)) {
                 if (probeType.equalsIgnoreCase(CloneIdentifierDE.PROBE_SET)) {
                    // convert probesetID to cloneIDs by going through GeneSymbol
                }
            }
        }
    }

    private Collection getCloneNamesFor(Collection geneSymbols) throws Exception {
        String cloneNameCol = getColumnName(_BROKER, CloneIdentifierDE.IMAGE_CLONE.class.getName());
        return getCloneOrProbeNamesFor(geneSymbols, cloneNameCol);
    }

    private Collection getCloneOrProbeNamesFor(Collection geneSymbols, String cloneOrProbeNameCol) throws Exception {
        String geneSymbolCol = getColumnName(_BROKER, GeneIdentifierDE.GeneSymbol.class.getName());
        Criteria clonOrProbeNameCrit = new Criteria();
        clonOrProbeNameCrit.addColumnIn(geneSymbolCol,  geneSymbols);
        org.apache.ojb.broker.query.Query cloneOrProbeNamesQuery =
                QueryFactory.newReportQuery(ReporterAll.class, new String[] {cloneOrProbeNameCol}, clonOrProbeNameCrit, true);
        Collection cloneNames = _BROKER.getCollectionByQuery(cloneOrProbeNamesQuery);
        return cloneNames;
    }

    private Collection getGeneSymbolsForProbeNames(Collection probeNameDEs) throws Exception {
        String probesetColName = getColumnName(_BROKER, (CloneIdentifierDE.ProbesetID.class.getName()));
        return getGeneSymbolsForCloneOrProbesetNames(probeNameDEs, probesetColName);
    }

    private Collection getGeneSymbolsForCloneOrProbesetNames(Collection probeOrCloneDEs, String probeOrCloneColName) throws Exception {
        String geneSymbolCol = getColumnName(_BROKER, GeneIdentifierDE.GeneSymbol.class.getName());

        Criteria cloneOrProbeCriteria = new Criteria();
        cloneOrProbeCriteria.addColumnIn(probeOrCloneColName, probeOrCloneDEs);

        org.apache.ojb.broker.query.Query geneSymbolQuery =
                QueryFactory.newReportQuery(ReporterAll.class, new String[] {geneSymbolCol}, cloneOrProbeCriteria , true);
        Collection geneSymbols = _BROKER.getCollectionByQuery(geneSymbolQuery);

        return geneSymbols;
    }

    private String getType(CloneOrProbeIDCriteria cloneProbeCrit ) {
        if (cloneProbeCrit != null ) {
            Collection cloneIDorProbeIDs = cloneProbeCrit.getIdentifiers();
             if (cloneIDorProbeIDs.size() > 0) {
                 CloneIdentifierDE obj =  (CloneIdentifierDE ) cloneIDorProbeIDs.iterator().next();
                 return obj.getCloneIDType();
             }
        }
        return "";
    }



    private static void addGeneIDCriteria( GeneIDCriteria  geneIDCrit, Criteria criteria, PersistenceBroker pb ) throws Exception {
        Collection geneIdDEs = geneIDCrit.getGeneIdentifiers();
        for (Iterator iterator = geneIdDEs.iterator(); iterator.hasNext();) {
            GeneIdentifierDE obj = (GeneIdentifierDE) iterator.next();
            addEqualCriteriaFor(obj.getValueObject(), obj.getClass().getName(), pb, criteria); ;
        }

     }

     private static void addCloneOrProbeCriteria( CloneOrProbeIDCriteria   cloneProbeCrit, Criteria criteria, PersistenceBroker pb ) throws Exception {
        if (cloneProbeCrit != null) {
            Collection geneIdDEs = cloneProbeCrit.getIdentifiers();
            for (Iterator iterator = geneIdDEs.iterator(); iterator.hasNext();) {
                CloneIdentifierDE  obj = (CloneIdentifierDE) iterator.next();

                addEqualCriteriaFor(obj.getValueObject(), obj.getClass().getName(), pb, criteria);
            }
        }

     }

     private static void addFoldChangeCriteria(FoldChangeCriteria  foldChangeCrit, PersistenceBroker pb, Criteria criteria) throws Exception {
        String columnName = getColumnName(pb, ExprFoldChangeDE.class.getName());
        Collection objs = foldChangeCrit.getFoldChangeObjects();
        Object[] foldObjs = (Object[]) objs.toArray();

         // Either only UpRegulation or DownRegulation
         if (foldObjs.length == 1) {
             ExprFoldChangeDE foldChgObj = (ExprFoldChangeDE) foldObjs[0];
             Double foldChange = new Double(foldChgObj.getValueObject().floatValue());
             addSingleUpORDownCriteria(foldChange, foldChgObj.getRegulationType(), columnName, criteria, pb);
         }

         // else it could be EITHER both (UpRegulation or DownRegulation) OR UnChangedRegulation
         else if (foldObjs.length == 2) {
            String type = ((ExprFoldChangeDE)foldObjs[0]).getRegulationType();
            if (type.equals(ExprFoldChangeDE.UNCHANGED_REGULATION_UPPER_LIMIT) || type.equals(ExprFoldChangeDE.UNCHANGED_REGULATION_DOWN_LIMIT) ) {
                addUnChangedCriteria(foldObjs, columnName, criteria, pb);
            }
            else if (type.equals(ExprFoldChangeDE.UP_REGULATION) || type.equals(ExprFoldChangeDE.DOWN_REGULATION) ) {
                addUpAndDownCriteria(foldObjs, columnName, criteria, pb);
            }
         }
         else {
            throw new Exception("Invalid number of FoldChange Criteria objects: " + foldObjs.length);
         }
     }

    private static void addUpAndDownCriteria(Object[] foldObjs, String columnName, Criteria criteria, PersistenceBroker pb) throws Exception {
        String type1 = ((ExprFoldChangeDE)foldObjs[0]).getRegulationType();
        Double foldChange1 = new Double(((ExprFoldChangeDE)foldObjs[0]).getValueObject().floatValue());
        addSingleUpORDownCriteria(foldChange1, type1, columnName, criteria, pb);

        String type2 = ((ExprFoldChangeDE)foldObjs[1]).getRegulationType();
        Double foldChange2 = new Double(((ExprFoldChangeDE)foldObjs[1]).getValueObject().floatValue());
        Criteria fold2Crit = new Criteria();
        addSingleUpORDownCriteria(foldChange2, type2, columnName, fold2Crit, pb);

        criteria.addOrCriteria(fold2Crit);
    }

     private static void addUnChangedCriteria(Object[] foldObjs, String columnName, Criteria criteria, PersistenceBroker pb) throws Exception {

        String type1 = ((ExprFoldChangeDE)foldObjs[0]).getRegulationType();
        Double upperLimit;
        Double lowerLimit;

        if (type1.equals(ExprFoldChangeDE.UNCHANGED_REGULATION_DOWN_LIMIT)) {
            upperLimit = new Double(((ExprFoldChangeDE) foldObjs[0]).getValueObject().floatValue());
            lowerLimit = new Double(((ExprFoldChangeDE)foldObjs[1]).getValueObject().floatValue());
        }
        else {
            upperLimit = new Double(((ExprFoldChangeDE)foldObjs[1]).getValueObject().floatValue());
            lowerLimit = new Double(((ExprFoldChangeDE)foldObjs[0]).getValueObject().floatValue());
        }
        criteria.addBetween(columnName, lowerLimit, upperLimit);
    }

    private static void addSingleUpORDownCriteria(Double foldChange, String type, String colunName, Criteria subCrit, PersistenceBroker pb) throws Exception {

        if (type.equals(ExprFoldChangeDE.UP_REGULATION)) {
            subCrit.addGreaterThan(colunName,foldChange);
        }
        else if (type.equals(ExprFoldChangeDE.DOWN_REGULATION)) {
            double convertedDownFold = 1 / (foldChange.doubleValue());
            subCrit.addLessThan(colunName, new Double(convertedDownFold));
        }
        else {
            throw new Exception("Invalid Regulation: " + type + " Value:" + foldChange);
        }

    }

    private static Criteria addRegionCriteria( RegionCriteria regionCrit, PersistenceBroker pb, Criteria criteria) throws Exception {
        if (regionCrit.getChromNumber() != null)
            addEqualCriteriaFor(regionCrit.getChromNumber().getValueObject(), ChromosomeNumberDE.class.getName(), pb, criteria);

        if (regionCrit.getStart() != null)
           addEqualCriteriaFor(regionCrit.getStart().getValueObject(), BasePairPositionDE.StartPosition.class.getName(), pb, criteria);

        if (regionCrit.getEnd() != null)
           addEqualCriteriaFor(regionCrit.getEnd().getValueObject(), BasePairPositionDE.EndPosition.class.getName(), pb, criteria);

        if (regionCrit.getCytoband() !=  null)
            addEqualCriteriaFor(regionCrit.getCytoband().getValueObject(), CytobandDE.class.getName(), pb, criteria);

        return criteria;
    }

    private static void addEqualCriteriaFor(Object deValueObject, String deClassName, PersistenceBroker pb, Criteria crit ) throws Exception {
        String colName = getColumnName(pb, deClassName);
        crit.addEqualTo(colName, deValueObject);
    }
    public static class CloneProbeCriteria {
        Collection cloneCrits;
        Collection probeCrtis;

        public Collection getCloneCrits() {
            return cloneCrits;
        }

        public void setCloneCrits(Collection cloneCrits) {
            this.cloneCrits = cloneCrits;
        }

        public Collection getProbeCrtis() {
            return probeCrtis;
        }

        public void setProbeCrtis(Collection probeCrtis) {
            this.probeCrtis = probeCrtis;
        }
    }
}
