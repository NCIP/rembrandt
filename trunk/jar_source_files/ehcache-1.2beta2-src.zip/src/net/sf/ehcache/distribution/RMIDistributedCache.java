/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 - 2004 Greg Luck.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by Greg Luck
 *       (http://sourceforge.net/users/gregluck) and contributors.
 *       See http://sourceforge.net/project/memberlist.php?group_id=93232
 *       for a list of contributors"
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "EHCache" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For written
 *    permission, please contact Greg Luck (gregluck at users.sourceforge.net).
 *
 * 5. Products derived from this software may not be called "EHCache"
 *    nor may "EHCache" appear in their names without prior written
 *    permission of Greg Luck.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL GREG LUCK OR OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by contributors
 * individuals on behalf of the EHCache project.  For more
 * information on EHCache, please see <http://ehcache.sourceforge.net/>.
 *
 */
package net.sf.ehcache.distribution;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheException;
import net.sf.ehcache.Element;
import net.sf.ehcache.Status;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.io.IOException;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 * A cache server which exposes available cache operations remotely through RMI.
 * <p/>
 * It holds an instance of cache, which is a local cache it talks to.
 * <p/>
 * This class could specify a security manager with code like:
 * <pre>
 * if (System.getSecurityManager() == null) {
 *     System.setSecurityManager(new RMISecurityManager());
 * }
 * </pre>
 * Doing so would require the addition of <code>grant</code> statements in the <code>java.policy</code> file.
 * <p/>
 * Per the JDK documentation: "If no security manager is specified no class loading, by RMI clients or servers, is allowed,
 * aside from what can be found in the local CLASSPATH." The classpath of each instance of this class should have
 * all required classes to enable distribution, so no remote classloading is required or desirable. Accordingly,
 * no security manager is set and there are no special JVM configuration requirements.
 *
 * @author Greg Luck
 * @version $Id: RMIDistributedCache.java,v 1.7 2005/10/03 02:47:22 gregluck Exp $
 */
public class RMIDistributedCache extends UnicastRemoteObject implements DistributedCache {

    private static final Log LOG = LogFactory.getLog(RMIDistributedCache.class.getName());
    private static Registry registry;

    private String hostname;
    private Integer port;
    private Cache cache;

    /**
     * Constructor with full arguements
     *
     * @param hostname may be null, in which case the hostname will be looked up. Machines with multiple
     * interfaces should specify this if they do not want it to be the default NIC.
     * @param port a port in the range 1025 - 65536
     * @param cache
     */
    public RMIDistributedCache(String hostname, Integer port, Cache cache) throws RemoteException,
            UnknownHostException {
        super();
        if (hostname != null) {
            this.hostname = hostname;
        } else {
            this.hostname = calculateHostAddress();
        }
        if (port == null) {
            throw new IllegalArgumentException("Port must be specified in the range 1025 - 65536");
        } else {
            this.port = port;
        }
        this.cache = cache;
        init();

    }

    private String calculateHostAddress() throws UnknownHostException {
        return InetAddress.getLocalHost().getHostAddress();
    }


    private void init() throws RemoteException {



        startRegistry();

        try {
            Naming.rebind("//" + hostname + ":" + port + "/" + cache.getName(), this);
            LOG.debug("Server bound in registry");
        } catch (Exception e) {
            LOG.fatal("Problem starting listener for cache: " + cache.getName() + " " + e.getMessage(), e);
            throw new RemoteException(e.getMessage(), e);
        }
    }

    /**
     * Start the rmiregistry
     * <p/>
     * The alternative is to use the <code>rmiregistry</code> binary, in which case:
     * <ol/>
     * <li>rmiregistry running
     * <li>-Djava.rmi.server.codebase="file:///Users/gluck/work/ehcache/build/classes/ file:///Users/gluck/work/ehcache/lib/commons-logging-1.0.4.jar"
     * </ol>
     *
     * @throws RemoteException
     */
    private void startRegistry() throws RemoteException {
        if (registry == null) {
            registry = LocateRegistry.createRegistry(port.intValue());
        }
    }


    /**
     *
     * @param element
     * @throws RemoteException
     * @throws IllegalArgumentException
     * @throws IllegalStateException
     */
    public void put(Element element) throws RemoteException, IllegalArgumentException, IllegalStateException {

    }


    /**
     * {@inheritDoc}
     */
    public Element get(Serializable key) throws RemoteException, IllegalStateException, CacheException {
        return cache.get(key);
    }


    /**
     * {@inheritDoc}
     * @throws RemoteException an RMI exception
     */
    public List getKeys() throws RemoteException, IllegalStateException, CacheException {
        return cache.getKeys();
    }


    /**
     *
     * @param key
     * @return
     * @throws RemoteException
     * @throws IllegalStateException
     */
    public boolean remove(Serializable key) throws RemoteException, IllegalStateException {
        return false;
    }

    /**
     * Removes all cached items.
     *
     * @throws IllegalStateException if the cache is not {@link Status#STATUS_ALIVE}
     */
    public void removeAll() throws IllegalStateException, IOException {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * Gets the status attribute of the Store object
     *
     * @return The status value
     */
    public Status getStatus() throws RemoteException {
        return Status.STATUS_UNINITIALISED;
    }

    /**
     * Gets the cache name
     */
    public String getName() throws RemoteException {
        return cache.getName();
    }


}
