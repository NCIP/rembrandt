/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 - 2004 Greg Luck.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by Greg Luck
 *       (http://sourceforge.net/users/gregluck) and contributors.
 *       See http://sourceforge.net/project/memberlist.php?group_id=93232
 *       for a list of contributors"
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "EHCache" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For written
 *    permission, please contact Greg Luck (gregluck at users.sourceforge.net).
 *
 * 5. Products derived from this software may not be called "EHCache"
 *    nor may "EHCache" appear in their names without prior written
 *    permission of Greg Luck.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL GREG LUCK OR OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by contributors
 * individuals on behalf of the EHCache project.  For more
 * information on EHCache, please see <http://ehcache.sourceforge.net/>.
 *
 */
package net.sf.ehcache.event;

import net.sf.ehcache.Cache;
import net.sf.ehcache.Element;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * A service for registering and unregistering CacheEventListeners and multicasting notifications to registrants.
 * <p/>
 * There is one of these per Cache
 *
 * @author Greg Luck
 * @version $Id: CacheEventNotificationService.java,v 1.4 2005/10/05 04:12:33 gregluck Exp $
 */
public class CacheEventNotificationService {

    /**
     * A Map of CacheEventListeners keyed by listener class.
     * CacheEventListener implementations that will be notified of this cache's events.
     *
     * @see CacheEventListener
     */
    private Set cacheEventListeners = new HashSet();
    private Cache cache;

    /**
     * Constructs a new notification service
     * @param cache
     */
    public CacheEventNotificationService(Cache cache) {
        this.cache = cache;
    }


    /**
     * Notifies all registered listeners, in no guaranteed order, that an element was removed
     * @param element
     * @see CacheEventListener#notifyElementRemoved
     */
    public void notifyElementRemoved(Element element) {
        Iterator iterator = cacheEventListeners.iterator();
        while (iterator.hasNext()) {
            CacheEventListener cacheEventListener = (CacheEventListener) iterator.next();
            cacheEventListener.notifyElementRemoved(cache, element);
        }
    }

    /**
     * Notifies all registered listeners, in no guaranteed order, that an element was put into the cache
     * @param element
     * @see CacheEventListener#notifyElementPut(net.sf.ehcache.Cache,net.sf.ehcache.Element)
     */
    public void notifyElementPut(Element element) {
        Iterator iterator = cacheEventListeners.iterator();
        while (iterator.hasNext()) {
            CacheEventListener cacheEventListener =  (CacheEventListener) iterator.next();
            cacheEventListener.notifyElementPut(cache, element);
        }
    }

    /**
     * Notifies all registered listeners, in no guaranteed order, that an element has expired
     * @param element
     * @see CacheEventListener#notifyElementExpired
     */
    public void notifyElementExpiry(Element element) {
        Iterator iterator = cacheEventListeners.iterator();
        while (iterator.hasNext()) {
            CacheEventListener cacheEventListener =  (CacheEventListener) iterator.next();
            cacheEventListener.notifyElementExpired(cache, element);
        }
    }

    /**
     * Adds a listener to the notification service. No guarantee is made that listeners will be
     * notified in the order they were added.
     * @param cacheEventListener
     * @return true if the listener is being added and was not already added
     */
    public boolean registerListener(CacheEventListener cacheEventListener) {
        return cacheEventListeners.add(cacheEventListener);
    }

    /**
     * Removes a listener from the notification service.
     * @param cacheEventListener
     * @return true if the listener was present
     */
    public boolean unregisterListener(CacheEventListener cacheEventListener) {
        return cacheEventListeners.remove(cacheEventListener);
    }

    /**
     * Gets a list of the listeners registered to this class
     * @return a list of type <code>CacheEventListener</code>
     */
    public Set getCacheEventListeners() {
        return cacheEventListeners;
    }


}
