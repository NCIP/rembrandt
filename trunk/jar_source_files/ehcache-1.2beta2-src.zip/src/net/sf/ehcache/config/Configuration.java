/* ====================================================================
 * The Apache Software License, Version 1.1
 *
 * Copyright (c) 2003 - 2004 Greg Luck.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 *
 * 3. The end-user documentation included with the redistribution, if
 *    any, must include the following acknowlegement:
 *       "This product includes software developed by Greg Luck
 *       (http://sourceforge.net/users/gregluck) and contributors.
 *       See http://sourceforge.net/project/memberlist.php?group_id=93232
 *       for a list of contributors"
 *    Alternately, this acknowledgement may appear in the software itself,
 *    if and wherever such third-party acknowlegements normally appear.
 *
 * 4. The names "EHCache" must not be used to endorse or promote products
 *    derived from this software without prior written permission. For written
 *    permission, please contact Greg Luck (gregluck at users.sourceforge.net).
 *
 * 5. Products derived from this software may not be called "EHCache"
 *    nor may "EHCache" appear in their names without prior written
 *    permission of Greg Luck.
 *
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED.  IN NO EVENT SHALL GREG LUCK OR OTHER
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 * USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 * ====================================================================
 *
 * This software consists of voluntary contributions made by contributors
 * individuals on behalf of the EHCache project.  For more
 * information on EHCache, please see <http://ehcache.sourceforge.net/>.
 *
 */


package net.sf.ehcache.config;

import net.sf.ehcache.CacheException;
import net.sf.ehcache.ObjectExistsException;
import net.sf.ehcache.event.CacheEventListener;
import net.sf.ehcache.event.CacheEventNotificationService;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

/**
 * The configuration for ehcache.
 * <p/>
 * This class can be populated through:
 * <ul>
 * <li>introspection by {@link Configurator} or
 * <li>programmatically
 * </ul>
 *
 * @author Greg Luck
 * @version $Id: Configuration.java,v 1.26 2005/10/03 02:47:22 gregluck Exp $
 */
public class Configuration {

    private static final Log LOG = LogFactory.getLog(Configuration.class.getName());

    private DiskStore diskStore;
    private DefaultCache defaultCache;
    private Map caches = new HashMap();
    private net.sf.ehcache.event.CacheManagerEventListener cacheManagerEventListener;

    /**
     * Package protected empty constructor for use by {@link Configurator}. This is not usable programmatically.
     */
    Configuration() {
    }

    /**
     * Full constructor. Any parameters can be left null, in which case defaults will apply, firstly from ehcache.xml
     * and if not found, ehcache-failsafe.xml
     *
     * @param diskStorePath             the path to the directory where cache .data and .index files are created.
     *                                  If the path is a Java System Property it is replaced by
     *                                  its value in the running VM. The following properties are translated:
     *                                  <ul>
     *                                  <li>user.home - User's home directory
     *                                  <li>user.dir - User's current working directory
     *                                  <li>java.io.tmpdir - Default temp file path
     *                                  </ul>
     * @param defaultCache              default cache configuration. Used by CacheManager to create a new cache by name only
     * @param cacheManagerEventListener the CacheManagerEventListener the CacheManager will use
     */
    public Configuration(String diskStorePath, DefaultCache defaultCache,
                         net.sf.ehcache.event.CacheManagerEventListener cacheManagerEventListener) {
        if (diskStorePath == null || defaultCache == null || cacheManagerEventListener == null) {
            throw new IllegalArgumentException("No parameters can be null.");
        }
        DiskStore diskStoreLocal = new DiskStore();
        diskStoreLocal.setPath(diskStorePath);
        try {
            addDiskStore(diskStoreLocal);
        } catch (ObjectExistsException e) {
            //cannot happen from an instance constructor
        }

        this.defaultCache = defaultCache;
        this.cacheManagerEventListener = cacheManagerEventListener;
    }

    /**
     * Allows {@link BeanHandler} to add disk store location to the configuration
     */
    public void addDiskStore(DiskStore diskStore) throws ObjectExistsException {
        if (this.diskStore != null) {
            throw new ObjectExistsException("The Disk Store has already been configured");
        }
        this.diskStore = diskStore;
    }

    /**
     * Allows {@link BeanHandler} to add the CacheManagerEventListener to the configuration
     */
    public void addCacheManagerEventListener(CacheManagerEventListener cacheManagerEventListener) throws ObjectExistsException {
        if (this.cacheManagerEventListener != null) {
            throw new ObjectExistsException("The CacheManagerEventListener has already been configured");
        }
        createCacheManagerEventListener(cacheManagerEventListener);
    }

    /**
     * Tries to load the class specified otherwise defaults to <code>NullCacheManagerEventListener</code> class.
     */
    private void createCacheManagerEventListener(CacheManagerEventListener cacheManagerEventListener) {
        String className = null;
        try {
            className = cacheManagerEventListener.fullyQualifiedClassPath;
        } catch (Throwable t) {
            //because no class created because the config was missing
        }
        if (className == null) {
            LOG.debug("No CacheManagerEventListener class specified. Using default.");
            className = "net.sf.ehcache.event.NullCacheManagerEventListener";
        }
        Class cacheManagerEventListenerClass = null;
        try {
            cacheManagerEventListenerClass = Class.forName(className);
            this.cacheManagerEventListener = (net.sf.ehcache.event.CacheManagerEventListener)
                    cacheManagerEventListenerClass.newInstance();
        } catch (ClassNotFoundException e) {
            LOG.info("Unable to load CacheManagerEventListener class " + className + ". " + e.getMessage()
                    + ". Using default.", e);
        } catch (IllegalAccessException e) {
            LOG.info("Unable to load CacheManagerEventListener class " + className + ". " + e.getMessage()
                    + ". Using default.", e);
        } catch (InstantiationException e) {
            LOG.info("Unable to load CacheManagerEventListener class " + className + ". " + e.getMessage()
                    + ". Using default.", e);
        }
    }

    /**
     * @return the CacheManagerEventListener which has been configured, or the default of
     *         <code>NullCacheManagerEventListener</code> if:
     *         <ul>
     *         <li>none was configured in ehcache.xml
     *         <li>the configured class could not be found
     *         <li>the configured class could not be accessed or a new instance instantiated
     *         </ul>
     *         If the default could not be used for any reason other than it was not configured, then an error is logged
     */
    public net.sf.ehcache.event.CacheManagerEventListener getCacheManagerEventListener() {
        if (cacheManagerEventListener == null) {
            //this will be the case where none was specified
            createCacheManagerEventListener(null);
        }
        return cacheManagerEventListener;
    }

    /**
     * Allows {@link BeanHandler} to add disk caches to the configuration
     */
    public void addDefaultCache(DefaultCache defaultCache) throws ObjectExistsException {
        if (this.defaultCache != null) {
            throw new ObjectExistsException("The Default Cache has already been configured");
        }
        this.defaultCache = defaultCache;
    }

    /**
     * Allows {@link BeanHandler} to add disk caches to the configuration
     */
    public void addCache(Cache cache) throws ObjectExistsException {
        if (caches.get(cache.name) != null) {
            throw new ObjectExistsException("Cannot create cache: " + cache.name
                    + " with the same name as an existing one.");
        }
        if (cache.name.equalsIgnoreCase(net.sf.ehcache.Cache.DEFAULT_CACHE_NAME)) {
            throw new ObjectExistsException("The Default Cache has already been configured");
        }

        caches.put(cache.name, cache);
    }

    /**
     * Gets the disk cache path
     */
    public String getDiskCachePath() {
        if (diskStore != null) {
            return diskStore.path;
        } else {
            return null;
        }
    }

    /**
     * @return the Default Cache
     * @throws CacheException if there is no default cache
     */
    public net.sf.ehcache.Cache getDefaultCache() throws CacheException {
        if (defaultCache == null) {
            throw new CacheException("Illegal configuration. No default cache is configured.");
        } else {
            return defaultCache.toCache();
        }
    }

    /**
     * Gets a Map of caches
     */
    public Set getCacheKeySet() {
        return caches.keySet();
    }

    /**
     * Gets a cache
     *
     * @param name the name of the cache
     * @return a new net.sf.ehcache.Cache
     */
    public net.sf.ehcache.Cache getCache(String name) {
        Cache cache = (Cache) caches.get(name);
        net.sf.ehcache.Cache constructedCache = cache.toCache();
        CacheEventNotificationService notificationService = constructedCache.getCacheEventNotificationService();
        cache.registerCacheListeners(constructedCache, notificationService);
        return constructedCache;
    }


    /**
     * A class to represent DiskStore configuration
     * e.g. <diskStore path="java.io.tmpdir" />
     */
    public static class DiskStore {
        private static final Log LOG = LogFactory.getLog(DiskStore.class.getName());

        private String path;

        /** The diskStore path */
        public String getPath() {
            return path;
        }

        /**
         * Translates and sets the path.
         *
         * @param path If the path contains a Java System Property it is replaced by
         *             its value in the running VM. The following properties are translated:
         *             <ul>
         *             <li><code>user.home</code> - User's home directory
         *             <li><code>user.dir</code> - User's current working directory
         *             <li><code>java.io.tmpdir</code> - Default temp file path
         *             </ul>
         *             e.g. <code>java.io/tmpdir/caches</code> might become <code>/tmp/caches</code>
         */
        public void setPath(final String path) {
            /** A constants class with method scope */
            class Env {
                static final String USER_HOME = "user.home";
                static final String USER_DIR = "user.dir";
                static final String JAVA_IO_TMPDIR = "java.io.tmpdir";
            }

            String translatedPath = replaceToken(Env.USER_HOME, System.getProperty(Env.USER_HOME), path);
            translatedPath = replaceToken(Env.USER_DIR, System.getProperty(Env.USER_DIR), translatedPath);
            translatedPath = replaceToken(Env.JAVA_IO_TMPDIR, System.getProperty(Env.JAVA_IO_TMPDIR), translatedPath);

            if (LOG.isDebugEnabled()) {
                LOG.debug("Disk Store Path: " + translatedPath);
            }
            this.path = translatedPath;
        }

        private String replaceToken(final String token, final String replacement, final String source) {
            int foundIndex = source.indexOf(token);
            if (foundIndex == -1) {
                return source;
            } else {
                String firstFragment = source.substring(0, foundIndex);
                String lastFragment = source.substring(foundIndex + token.length(), source.length());
                return new StringBuffer()
                        .append(firstFragment)
                        .append(replacement)
                        .append(lastFragment)
                        .toString();
            }
        }

    }


    /**
     * A class to represent the CacheManagerEventListener configuration
     * e.g. <cacheManagerEventListener class="net.sf.ehcache.event.NullCacheManagerEventListener"/>
     */
    public static class CacheManagerEventListener {
        private String fullyQualifiedClassPath;


        /**
         * Sets the class name
         *
         * @param fullyQualifiedClassPath
         */
        public void setClass(String fullyQualifiedClassPath) {
            this.fullyQualifiedClassPath = fullyQualifiedClassPath;
        }
    }


    /**
     * A class to represent Cache configuration
     * e.g.
     * <cache name="testCache1"
     * maxElementsInMemory="10000"
     * eternal="false"
     * timeToIdleSeconds="3600"
     * timeToLiveSeconds="10"
     * overflowToDisk="true"
     * diskPersistent="true"
     * diskExpiryThreadIntervalSeconds="120"
     * />
     */
    public static class Cache {

        /**
         * the name of the cache
         */
        protected String name;

        /**
         * the maximum objects to be held in the {@link net.sf.ehcache.store.MemoryStore}
         */
        protected int maxElementsInMemory;

        /**
         * The policy used to evict elements from the {@link net.sf.ehcache.store.MemoryStore}.
         * This can be one of:
         * <ol>
         * <li>LRU - least recently used
         * <li>LFU - least frequently used
         * <li>FIFO - first in first out, the oldest element by creation time
         * </ol>
         * The default value is LRU
         *
         * @since 1.2
         */
        protected MemoryStoreEvictionPolicy memoryStoreEvictionPolicy;


        /**
         * Sets whether elements are eternal. If eternal,  timeouts are ignored and the element
         * is never expired.
         */
        protected boolean eternal;

        /**
         * the time to idle for an element before it expires. Is only used
         * if the element is not eternal.A value of 0 means do not check for idling.
         */
        protected int timeToIdleSeconds;

        /**
         * Sets the time to idle for an element before it expires. Is only used
         * if the element is not eternal. This attribute is optional in the configuration.
         * A value of 0 means do not check time to live.
         */
        protected int timeToLiveSeconds;

        /**
         * whether elements can overflow to disk when the in-memory cache
         * has reached the set limit.
         */
        protected boolean overflowToDisk;

        /**
         * For caches that overflow to disk, does the disk cache persist between CacheManager instances?
         */
        protected boolean diskPersistent;

        /**
         * The interval in seconds between runs of the disk expiry thread.
         * <p/>
         * 2 minutes is the default.
         * This is not the same thing as time to live or time to idle. When the thread runs it checks
         * these things. So this value is how often we check for expiry.
         */
        protected long diskExpiryThreadIntervalSeconds;

        /**
         * An instance of a class that implements CacheEventListener.
         */
        protected List cacheEventListeners = new ArrayList();

        /**
         * Sets the name of the cache. This must be unique
         */
        public void setName(String name) {
            this.name = name;
        }

        /**
         * Sets the maximum objects to be held in memory
         */
        public void setMaxElementsInMemory(int maxElementsInMemory) {
            this.maxElementsInMemory = maxElementsInMemory;
        }

        /**
         * Sets the eviction policy. An invalid argument will set it to null
         */
        public void setMemoryStoreEvictionPolicy(String memoryStoreEvictionPolicy) {
            this.memoryStoreEvictionPolicy = MemoryStoreEvictionPolicy.fromString(memoryStoreEvictionPolicy);
        }

        /**
         * Sets whether elements are eternal. If eternal,  timeouts are ignored and the element
         * is never expired.
         */
        public void setEternal(boolean eternal) {
            this.eternal = eternal;
        }

        /**
         * Sets the time to idle for an element before it expires. Is only used
         * if the element is not eternal.
         */
        public void setTimeToIdleSeconds(int timeToIdleSeconds) {
            this.timeToIdleSeconds = timeToIdleSeconds;
        }

        /**
         * Sets the time to idle for an element before it expires. Is only used
         * if the element is not eternal.
         */
        public void setTimeToLiveSeconds(int timeToLiveSeconds) {
            this.timeToLiveSeconds = timeToLiveSeconds;
        }

        /**
         * Sets whether elements can overflow to disk when the in-memory cache
         * has reached the set limit.
         */
        public void setOverflowToDisk(boolean overflowToDisk) {
            this.overflowToDisk = overflowToDisk;
        }

        /**
         * Sets whether, for caches that overflow to disk,
         * the disk cache persist between CacheManager instances
         */
        public void setDiskPersistent(boolean diskPersistent) {
            this.diskPersistent = diskPersistent;
        }

        /**
         * Sets the interval in seconds between runs of the disk expiry thread.
         * <p/>
         * 2 minutes is the default.
         * This is not the same thing as time to live or time to idle. When the thread runs it checks
         * these things. So this value is how often we check for expiry.
         */
        public void setDiskExpiryThreadIntervalSeconds(int diskExpiryThreadIntervalSeconds) {
            this.diskExpiryThreadIntervalSeconds = diskExpiryThreadIntervalSeconds;
        }

        /**
         * Sets the name of the class to be instantiated as a CacheEventListener for this
         * class.
         *
         * @param cacheEventListenerClassNames a comma separated list of fully qualified listener class names
         */
        public void setCacheEventListenerClassNames(final String cacheEventListenerClassNames) {

            if (cacheEventListenerClassNames == null || cacheEventListenerClassNames.length() == 0) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("Empty list of cacheEventListenerClassNames. No listeners registered.");
                }
                return;
            }
            StringTokenizer tokenizer = new StringTokenizer(cacheEventListenerClassNames, ",");
            while (tokenizer.hasMoreElements()) {
                String className = tokenizer.nextToken().trim();
                Class cacheEventListenerClass = null;
                try {
                    cacheEventListenerClass = Class.forName(className);
                    CacheEventListener cacheEventListener = (net.sf.ehcache.event.CacheEventListener)
                            cacheEventListenerClass.newInstance();
                    cacheEventListeners.add(cacheEventListener);
                } catch (ClassNotFoundException e) {
                    LOG.error("Unable to load CacheEventListener class " + className + ". " + e.getMessage(), e);
                } catch (IllegalAccessException e) {
                    LOG.error("Unable to load CacheEventListener class " + className + ". " + e.getMessage(), e);
                } catch (InstantiationException e) {
                    LOG.error("Unable to load CacheEventListener class " + className + ". " + e.getMessage(), e);
                }
            }

        }

        /**
         * A factory method to create a CacheEventNotificationService
         */
        protected void registerCacheListeners(net.sf.ehcache.Cache cache,
                        CacheEventNotificationService cacheEventNotificationService) {
            for (int i = 0; i < cacheEventListeners.size(); i++) {
                CacheEventListener cacheEventListener = (CacheEventListener) cacheEventListeners.get(i);
                cacheEventNotificationService.registerListener(cacheEventListener);
            }
        }


        /**
         * @return a new Cache with this configuration
         * @since 1.2
         */
        private net.sf.ehcache.Cache toCache() {


            return new net.sf.ehcache.Cache(name,
                    maxElementsInMemory,
                    memoryStoreEvictionPolicy,
                    overflowToDisk,
                    eternal,
                    timeToLiveSeconds,
                    timeToIdleSeconds,
                    diskPersistent,
                    diskExpiryThreadIntervalSeconds,
                    null);
        }

    }

    /**
     * A class to represent the default cache
     * e.g.
     * <defaultCache
     * maxElementsInMemory="10000"
     * eternal="false"
     * timeToIdleSeconds="3600"
     * timeToLiveSeconds="10"
     * overflowToDisk="true"
     * />
     */
    public static class DefaultCache extends Cache {

        /**
         * @return a new Cache with this configuration
         * @since 1.2
         */
        private net.sf.ehcache.Cache toCache() {
            String defaultCacheName = net.sf.ehcache.Cache.DEFAULT_CACHE_NAME;
            return new net.sf.ehcache.Cache(defaultCacheName,
                    maxElementsInMemory,
                    memoryStoreEvictionPolicy,
                    overflowToDisk,
                    eternal,
                    timeToLiveSeconds,
                    timeToIdleSeconds,
                    diskPersistent,
                    diskExpiryThreadIntervalSeconds,
                    null);
        }
    }
}
