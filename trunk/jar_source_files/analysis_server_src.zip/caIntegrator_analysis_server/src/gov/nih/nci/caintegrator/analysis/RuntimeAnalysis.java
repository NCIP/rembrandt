package gov.nih.nci.caintegrator.analysis;

public interface RuntimeAnalysis {
	

}
