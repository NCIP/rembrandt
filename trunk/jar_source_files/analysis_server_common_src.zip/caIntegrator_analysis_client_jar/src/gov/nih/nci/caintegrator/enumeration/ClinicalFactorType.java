package gov.nih.nci.caintegrator.enumeration;

public  enum ClinicalFactorType {
	AgeAtDx, 
	Treatment, 
	KarnofskyAssessment, 
	SurvivalLength,
	Gender,
	Disease,
	Censor};
	

