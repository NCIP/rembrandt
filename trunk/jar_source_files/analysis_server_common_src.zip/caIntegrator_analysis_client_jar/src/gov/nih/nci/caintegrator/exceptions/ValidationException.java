package gov.nih.nci.caintegrator.exceptions;

public class ValidationException extends FrameworkException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValidationException(String string) {
		super(string);
	}

}
