package gov.nih.nci.caintegrator.enumeration;

import java.io.Serializable;

public enum LinkageMethodType implements Serializable{
	Average,Single,Complete;
}

