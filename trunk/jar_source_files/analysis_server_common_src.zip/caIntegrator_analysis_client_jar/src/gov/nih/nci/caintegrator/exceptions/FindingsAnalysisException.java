package gov.nih.nci.caintegrator.exceptions;

public class FindingsAnalysisException extends FrameworkException {

	public FindingsAnalysisException(String string) {
		super(string);
	}

}
