package gov.nih.nci.caintegrator.enumeration;

import java.io.Serializable;

public enum StatisticalSignificanceType implements Serializable{
	pValue,
	adjustedpValue;
}
