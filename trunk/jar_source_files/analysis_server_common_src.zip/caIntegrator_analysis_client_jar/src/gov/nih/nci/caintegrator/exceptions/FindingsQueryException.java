package gov.nih.nci.caintegrator.exceptions;

public class FindingsQueryException extends FrameworkException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FindingsQueryException(String string) {
		super(string);
	}

}
