package gov.nih.nci.caintegrator.enumeration;

import java.io.Serializable;

public enum DistanceMatrixType implements Serializable {
	Correlation, Euclidean;
}

