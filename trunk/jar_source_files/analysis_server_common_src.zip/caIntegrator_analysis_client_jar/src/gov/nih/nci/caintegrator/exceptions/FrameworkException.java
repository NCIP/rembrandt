package gov.nih.nci.caintegrator.exceptions;

public class FrameworkException extends Throwable {

	private static final long serialVersionUID = 1L;

	public FrameworkException(String string) {
		super(string);
	}
}
