package gov.nih.nci.caintegrator.enumeration;

import java.io.Serializable;

public enum ClusterByType implements Serializable{
	Genes, Samples;
}

